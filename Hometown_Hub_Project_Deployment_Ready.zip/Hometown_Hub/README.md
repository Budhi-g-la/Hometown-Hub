# Hometown Hub – Digital Community Platform

A responsive community networking web application built with Python Flask, SQLite, HTML, CSS and JavaScript.

## Features
- Registration, login and profile management
- Browse and create hometown communities (new communities require admin approval)
- Join communities, publish text/image posts, like and comment
- Report inappropriate posts
- Create and join local events
- Notifications
- Admin dashboard with platform counts, community approvals and report handling

## Requirements
- Python 3.9+
- pip

## Run on Windows
1. Extract `Hometown_Hub.zip`.
2. Open the extracted `Hometown_Hub` folder in VS Code.
3. Open Terminal and run:

```bash
python -m venv venv
venv\\Scripts\\activate
pip install -r requirements.txt
python app.py
```

4. Open `http://127.0.0.1:5000` in your browser.

## Local demo administrator
- Email: `admin@hometownhub.local`
- Password: `Admin@123`

These credentials are for local demonstration only. Do not use this password on a public deployment. The app reads `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and `SECRET_KEY` from environment variables. Set a unique administrator password during deployment. The admin account is created only when that email does not already exist in the database.

## Deploy on Render

This project includes `render.yaml` for Render Blueprint deployment. After the project is pushed to a GitHub repository:

1. Sign in to Render and choose **New → Blueprint**.
2. Connect the GitHub repository containing this project and select its branch.
3. Render reads `render.yaml` and prepares the web service.
4. During initial setup, enter a strong, unique value for `ADMIN_PASSWORD`. Keep it private.
5. Complete deployment and open the generated `onrender.com` URL.

The free Render service uses the app's local SQLite file, which is not durable storage. Demo users, posts, events, and uploaded images may be lost when the service is rebuilt or its instance is replaced. For a production service, migrate to a managed database and persistent/object storage.

## Notes
- SQLite database `hometown_hub.db` is created automatically on first run.
- Uploaded images are stored in `static/uploads/`.
- This is an internship/demo starter build. Before public production use, add CSRF protection, rate limiting, email verification, stronger moderation workflows, backups, secure secret configuration, and cloud object storage.
- Event dates are stored as entered. For a production deployment, validate time zones and past dates server-side.
