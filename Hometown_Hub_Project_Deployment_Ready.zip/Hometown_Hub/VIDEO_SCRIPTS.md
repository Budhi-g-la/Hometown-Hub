# Hometown Hub – Video Scripts

Replace bracketed text with your real details. Do not say that a feature or experience happened unless you have personally verified it.

## 1. Project Explanation Video (about 2–3 minutes)

Hello, my name is [Your Name]. In this video, I am presenting my project, **Hometown Hub – Digital Community Platform**.

The main objective of Hometown Hub is to help people from the same hometown or local area connect with one another. Members can share updates, interact with other residents, discover local communities, and participate in events.

The project is developed using Python Flask for the backend, SQLite for the database, and HTML, CSS, and JavaScript for the user interface.

I will now demonstrate the application. This is the home page, where visitors can view community information, recent posts, and upcoming events. A new member can create an account or log in. After logging in, the member can browse communities, join a community, and request the creation of a new community.

Members can publish posts, add images, like posts, write comments, and report inappropriate content. The events section allows members to view local events, create events, and join events. The notification page displays account notifications, and the profile page allows a member to update their name and hometown.

The application also includes an administrator dashboard. The administrator can review community requests, approve or reject them, view reports, close reports, and see basic platform statistics.

This project demonstrates how a digital platform can support communication and community participation. Some improvements for a larger real-world deployment would include stronger moderation, email verification, CSRF protection, a managed database, and persistent file storage.

Thank you for watching my project demonstration.

## 2. Internship Experience and Feedback Video (about 1 minute)

Hello, my name is [Your Name]. I am sharing my experience and feedback about my internship.

During this internship, I worked on the project **Hometown Hub – Digital Community Platform**. Through this project, I practised [mention the technologies and tasks you actually worked on]. I gained a better understanding of how a web application is organised, how its pages communicate with the backend, and how application data is stored and retrieved.

One challenge I faced was [mention a real challenge]. I worked on it by [explain what you actually did]. This helped me improve my problem-solving and technical skills.

My overall learning experience was [share your honest feedback about the training, mentor support, and project guidance]. I would like to thank [mention the real organisation, trainer, or mentor] for the opportunity and guidance.

Thank you.

## Recording and sharing

1. Record the project explanation while showing the actual running application on your screen.
2. Record the internship feedback video separately, speaking in your own words and replacing every bracketed section with true details.
3. Upload each recording to a service that provides a shareable HTTPS link, such as YouTube or Google Drive.
4. Check the sharing permissions from a private/incognito window before submitting the links.
