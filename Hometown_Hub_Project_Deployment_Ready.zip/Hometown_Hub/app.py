from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3, os
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-this-secret-key")
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE", "false").lower() == "true",
)
DB = os.environ.get("DATABASE_PATH", os.path.join(os.path.dirname(__file__), "hometown_hub.db"))
os.makedirs(os.path.dirname(os.path.abspath(DB)), exist_ok=True)
UPLOAD = os.path.join(os.path.dirname(__file__), "static", "uploads")
os.makedirs(UPLOAD, exist_ok=True)

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL, hometown TEXT DEFAULT '', role TEXT DEFAULT 'user',
          created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS communities(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, location TEXT NOT NULL,
          description TEXT, creator_id INTEGER, approved INTEGER DEFAULT 1,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(creator_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS memberships(
          user_id INTEGER, community_id INTEGER, status TEXT DEFAULT 'joined',
          PRIMARY KEY(user_id, community_id),
          FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(community_id) REFERENCES communities(id));
        CREATE TABLE IF NOT EXISTS posts(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, community_id INTEGER,
          body TEXT NOT NULL, image TEXT, pinned INTEGER DEFAULT 0,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(community_id) REFERENCES communities(id));
        CREATE TABLE IF NOT EXISTS comments(
          id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER, user_id INTEGER, body TEXT NOT NULL,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(post_id) REFERENCES posts(id), FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS likes(
          user_id INTEGER, post_id INTEGER, PRIMARY KEY(user_id, post_id),
          FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(post_id) REFERENCES posts(id));
        CREATE TABLE IF NOT EXISTS events(
          id INTEGER PRIMARY KEY AUTOINCREMENT, community_id INTEGER, creator_id INTEGER,
          title TEXT NOT NULL, details TEXT, event_date TEXT NOT NULL, venue TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(community_id) REFERENCES communities(id), FOREIGN KEY(creator_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS event_members(
          user_id INTEGER, event_id INTEGER, PRIMARY KEY(user_id, event_id),
          FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(event_id) REFERENCES events(id));
        CREATE TABLE IF NOT EXISTS notifications(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, message TEXT NOT NULL,
          read INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS reports(
          id INTEGER PRIMARY KEY AUTOINCREMENT, reporter_id INTEGER, post_id INTEGER,
          reason TEXT, status TEXT DEFAULT 'open', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        """)
        admin_email = os.environ.get("ADMIN_EMAIL", "admin@hometownhub.local").strip().lower()
        admin_password = os.environ.get("ADMIN_PASSWORD", "Admin@123")
        if not c.execute("SELECT id FROM users WHERE email=?", (admin_email,)).fetchone():
            c.execute("INSERT INTO users(name,email,password,hometown,role) VALUES(?,?,?,?,?)",
                      ("Platform Admin", admin_email, generate_password_hash(admin_password), "Bengaluru", "admin"))
        if c.execute("SELECT COUNT(*) n FROM communities").fetchone()["n"] == 0:
            c.execute("INSERT INTO communities(name,location,description,creator_id) VALUES(?,?,?,?)",
                      ("Bengaluru Community","Bengaluru, Karnataka","Connect with people, events and updates from Bengaluru.",1))

init_db()

def current_user():
    if "user_id" not in session: return None
    with db() as c:
        return c.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()

def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*a, **kw):
        if not current_user():
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapper

@app.context_processor
def inject():
    u = current_user()
    count = 0
    if u:
        with db() as c:
            count = c.execute("SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read=0",(u["id"],)).fetchone()["n"]
    return {"user":u, "notice_count":count}

@app.route("/")
def index():
    with db() as c:
        communities = c.execute("SELECT communities.*, COUNT(memberships.user_id) members FROM communities LEFT JOIN memberships ON communities.id=memberships.community_id WHERE approved=1 GROUP BY communities.id ORDER BY members DESC").fetchall()
        posts = c.execute("""SELECT posts.*, users.name, communities.name community,
          (SELECT COUNT(*) FROM likes WHERE likes.post_id=posts.id) likes,
          (SELECT COUNT(*) FROM comments WHERE comments.post_id=posts.id) comments
          FROM posts JOIN users ON users.id=posts.user_id JOIN communities ON communities.id=posts.community_id
          ORDER BY posts.pinned DESC, posts.created_at DESC LIMIT 8""").fetchall()
        events = c.execute("""SELECT events.*, communities.name community FROM events
          JOIN communities ON communities.id=events.community_id WHERE event_date>=date('now')
          ORDER BY event_date LIMIT 4""").fetchall()
    return render_template("index.html", communities=communities, posts=posts, events=events)

@app.route("/signup", methods=["GET","POST"])
def signup():
    if request.method=="POST":
        name=request.form["name"].strip(); email=request.form["email"].strip().lower()
        password=request.form["password"]; hometown=request.form.get("hometown","").strip()
        if len(password)<6:
            flash("Password must contain at least 6 characters.","danger")
        else:
            try:
                with db() as c:
                    c.execute("INSERT INTO users(name,email,password,hometown) VALUES(?,?,?,?)",
                              (name,email,generate_password_hash(password),hometown))
                    uid=c.execute("SELECT id FROM users WHERE email=?",(email,)).fetchone()["id"]
                session["user_id"]=uid
                flash("Welcome to Hometown Hub!","success")
                return redirect(url_for("index"))
            except sqlite3.IntegrityError:
                flash("That email is already registered.","danger")
    return render_template("auth.html", mode="signup")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        with db() as c:
            u=c.execute("SELECT * FROM users WHERE email=?",(request.form["email"].lower(),)).fetchone()
        if u and check_password_hash(u["password"],request.form["password"]):
            session["user_id"]=u["id"]
            return redirect(url_for("admin") if u["role"]=="admin" else url_for("index"))
        flash("Invalid email or password.","danger")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("index"))

@app.route("/communities")
def communities():
    with db() as c:
        rows=c.execute("""SELECT communities.*, COUNT(memberships.user_id) members FROM communities
        LEFT JOIN memberships ON communities.id=memberships.community_id
        WHERE approved=1 GROUP BY communities.id ORDER BY communities.name""").fetchall()
    return render_template("communities.html", communities=rows)

@app.route("/community/create", methods=["POST"])
@login_required
def create_community():
    with db() as c:
        c.execute("INSERT INTO communities(name,location,description,creator_id,approved) VALUES(?,?,?,?,?)",
                  (request.form["name"],request.form["location"],request.form.get("description",""),session["user_id"],0))
        c.execute("INSERT INTO notifications(user_id,message) VALUES(?,?)",
                  (session["user_id"],"Your community request has been submitted for admin approval."))
    flash("Community request submitted for approval.","success")
    return redirect(url_for("communities"))

@app.route("/community/<int:cid>")
def community(cid):
    with db() as c:
        community=c.execute("SELECT * FROM communities WHERE id=? AND approved=1",(cid,)).fetchone()
        if not community: return "Community not found",404
        posts=c.execute("""SELECT posts.*, users.name,
          (SELECT COUNT(*) FROM likes WHERE post_id=posts.id) likes,
          (SELECT COUNT(*) FROM comments WHERE post_id=posts.id) comments
          FROM posts JOIN users ON users.id=posts.user_id WHERE community_id=?
          ORDER BY pinned DESC, created_at DESC""",(cid,)).fetchall()
        members=c.execute("SELECT COUNT(*) n FROM memberships WHERE community_id=?",(cid,)).fetchone()["n"]
        joined=False
        if session.get("user_id"):
            joined=bool(c.execute("SELECT 1 FROM memberships WHERE user_id=? AND community_id=?",(session["user_id"],cid)).fetchone())
    return render_template("community.html", community=community, posts=posts, members=members, joined=joined)

@app.route("/community/<int:cid>/join", methods=["POST"])
@login_required
def join(cid):
    with db() as c:
        c.execute("INSERT OR IGNORE INTO memberships(user_id,community_id) VALUES(?,?)",(session["user_id"],cid))
        admins=c.execute("SELECT creator_id FROM communities WHERE id=?",(cid,)).fetchone()
        if admins and admins["creator_id"]:
            c.execute("INSERT INTO notifications(user_id,message) VALUES(?,?)",(admins["creator_id"],"A new member joined your community."))
    flash("You joined the community.","success")
    return redirect(url_for("community",cid=cid))

@app.route("/community/<int:cid>/post", methods=["POST"])
@login_required
def add_post(cid):
    body=request.form.get("body","").strip()
    if not body:
        flash("Write something before posting.","danger")
        return redirect(url_for("community",cid=cid))
    image_name=None
    f=request.files.get("image")
    if f and f.filename:
        image_name=datetime.now().strftime("%Y%m%d%H%M%S_")+secure_filename(f.filename)
        f.save(os.path.join(UPLOAD,image_name))
    with db() as c:
        c.execute("INSERT INTO posts(user_id,community_id,body,image) VALUES(?,?,?,?)",(session["user_id"],cid,body,image_name))
    return redirect(url_for("community",cid=cid))

@app.route("/post/<int:pid>/like", methods=["POST"])
@login_required
def like(pid):
    with db() as c:
        exists=c.execute("SELECT 1 FROM likes WHERE user_id=? AND post_id=?",(session["user_id"],pid)).fetchone()
        if exists: c.execute("DELETE FROM likes WHERE user_id=? AND post_id=?",(session["user_id"],pid))
        else: c.execute("INSERT INTO likes(user_id,post_id) VALUES(?,?)",(session["user_id"],pid))
        p=c.execute("SELECT community_id FROM posts WHERE id=?",(pid,)).fetchone()
    return redirect(request.referrer or url_for("index"))

@app.route("/post/<int:pid>/comment", methods=["POST"])
@login_required
def comment(pid):
    body=request.form["body"].strip()
    if body:
        with db() as c: c.execute("INSERT INTO comments(post_id,user_id,body) VALUES(?,?,?)",(pid,session["user_id"],body))
    return redirect(request.referrer or url_for("index"))

@app.route("/post/<int:pid>/report", methods=["POST"])
@login_required
def report(pid):
    with db() as c:
        c.execute("INSERT INTO reports(reporter_id,post_id,reason) VALUES(?,?,?)",(session["user_id"],pid,request.form.get("reason","Inappropriate content")))
    flash("Report sent to the platform admin.","success")
    return redirect(request.referrer or url_for("index"))

@app.route("/events")
def events():
    with db() as c:
        rows=c.execute("""SELECT events.*, communities.name community, users.name organizer,
        (SELECT COUNT(*) FROM event_members WHERE event_id=events.id) attendees
        FROM events JOIN communities ON communities.id=events.community_id
        JOIN users ON users.id=events.creator_id ORDER BY event_date""").fetchall()
    communities=c.execute("SELECT id,name FROM communities WHERE approved=1 ORDER BY name").fetchall()
    return render_template("events.html",events=rows,get_communities=communities)

@app.route("/event/create",methods=["POST"])
@login_required
def create_event():
    with db() as c:
        c.execute("INSERT INTO events(community_id,creator_id,title,details,event_date,venue) VALUES(?,?,?,?,?,?)",
          (request.form["community_id"],session["user_id"],request.form["title"],request.form.get("details",""),request.form["event_date"],request.form.get("venue","")))
    flash("Event created successfully.","success")
    return redirect(url_for("events"))

@app.route("/event/<int:eid>/join",methods=["POST"])
@login_required
def join_event(eid):
    with db() as c: c.execute("INSERT OR IGNORE INTO event_members(user_id,event_id) VALUES(?,?)",(session["user_id"],eid))
    flash("You are attending this event.","success")
    return redirect(url_for("events"))

@app.route("/notifications")
@login_required
def notifications():
    with db() as c:
        rows=c.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC",(session["user_id"],)).fetchall()
        c.execute("UPDATE notifications SET read=1 WHERE user_id=?",(session["user_id"],))
    return render_template("notifications.html",notifications=rows)

@app.route("/profile",methods=["GET","POST"])
@login_required
def profile():
    if request.method=="POST":
        with db() as c: c.execute("UPDATE users SET name=?,hometown=? WHERE id=?",(request.form["name"],request.form["hometown"],session["user_id"]))
        flash("Profile updated.","success")
    with db() as c: u=c.execute("SELECT * FROM users WHERE id=?",(session["user_id"],)).fetchone()
    return render_template("profile.html",profile=u)

@app.route("/admin")
@login_required
def admin():
    if current_user()["role"]!="admin": return "Access denied",403
    with db() as c:
        stats={
          "users":c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"],
          "communities":c.execute("SELECT COUNT(*) n FROM communities").fetchone()["n"],
          "posts":c.execute("SELECT COUNT(*) n FROM posts").fetchone()["n"],
          "events":c.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]}
        pending=c.execute("SELECT * FROM communities WHERE approved=0").fetchall()
        reports=c.execute("""SELECT reports.*, users.name reporter FROM reports JOIN users ON users.id=reports.reporter_id
          ORDER BY reports.created_at DESC""").fetchall()
        all_users=c.execute("SELECT id,name,email,role FROM users ORDER BY id DESC").fetchall()
    return render_template("admin.html",stats=stats,pending=pending,reports=reports,all_users=all_users)

@app.route("/admin/community/<int:cid>/<action>",methods=["POST"])
@login_required
def approve_community(cid,action):
    if current_user()["role"]!="admin": return "Access denied",403
    with db() as c:
        if action=="approve":
            c.execute("UPDATE communities SET approved=1 WHERE id=?",(cid,))
            owner=c.execute("SELECT creator_id FROM communities WHERE id=?",(cid,)).fetchone()
            if owner and owner["creator_id"]: c.execute("INSERT INTO notifications(user_id,message) VALUES(?,?)",(owner["creator_id"],"Your community has been approved."))
        elif action=="reject": c.execute("DELETE FROM communities WHERE id=?",(cid,))
    return redirect(url_for("admin"))

@app.route("/admin/report/<int:rid>/close",methods=["POST"])
@login_required
def close_report(rid):
    if current_user()["role"]!="admin": return "Access denied",403
    with db() as c: c.execute("UPDATE reports SET status='closed' WHERE id=?",(rid,))
    return redirect(url_for("admin"))

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=int(os.environ.get("PORT", "5000")),
        debug=os.environ.get("FLASK_DEBUG", "0") == "1",
    )
