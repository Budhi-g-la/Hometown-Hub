# Hometown Hub – Project Documentation

## 1. Introduction
Hometown Hub is a web-based digital community platform that helps people stay connected with their city, village or hometown. It brings community discussions, local announcements and events into one structured space.

## 2. Problem statement
People who move for education or employment may lose touch with their hometown. Local communication is often fragmented across messaging groups, and community news and events can be difficult to discover.

## 3. Objectives
- Connect people belonging to the same hometown.
- Centralise local posts, discussions and announcements.
- Support community creation and membership.
- Allow residents to create and join local events.
- Give moderators and administrators basic content-management tools.

## 4. Scope
Included: responsive web application, user accounts, communities, posts, comments, likes, events, notifications and admin dashboard.
Not included in this Phase 1 build: native mobile app, paid advertisements, AI moderation, government emergency integrations and marketplace.

## 5. Technology stack
- Frontend: HTML5, CSS3, JavaScript
- Backend: Python Flask
- Database: SQLite
- Authentication: Werkzeug password hashing and Flask sessions
- Deployment target: any Python hosting service supporting Flask

## 6. Main modules
1. User authentication and profile
2. Community discovery and membership
3. Community posts, image upload, likes and comments
4. Events and attendance
5. Notifications
6. Admin approval and report management

## 7. Database entities
Users, Communities, Memberships, Posts, Comments, Likes, Events, EventMembers, Notifications and Reports.

## 8. User flow
Visit platform → sign up/login → browse communities → join a community → publish/interact with posts → discover or create events → receive notifications.

## 9. Admin flow
Admin login → review pending community requests → approve/reject requests → review abuse reports → close reports → monitor platform counts and registered users.

## 10. Security and limitations
Passwords are stored as hashes. Database relationships use foreign keys. The demo build should be enhanced with CSRF protection, rate limiting, stricter file validation, email verification, secure secret management and production database hosting before public launch.

## 11. Future enhancements
- Android/iOS mobile application
- Multi-language interface
- Local marketplace and classifieds
- Emergency and civic alerts
- Advanced moderation and analytics
- Integration with verified local-government information

## 12. Expected impact
Hometown Hub can improve access to local information, encourage participation in community events, strengthen relationships and support preservation of local culture.


## Deployment configuration

The repository includes `render.yaml` and Gunicorn configuration for a Render Python web service. Deployment requires a connected GitHub repository and a unique administrator password supplied through the Render Blueprint setup. The free demo deployment stores SQLite data and uploaded files on the service's temporary filesystem; use managed/persistent storage before production use.
