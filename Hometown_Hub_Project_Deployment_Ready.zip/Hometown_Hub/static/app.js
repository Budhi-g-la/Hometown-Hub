document.querySelectorAll('form').forEach(form => {
  form.addEventListener('submit', () => {
    const button = form.querySelector('button[type="submit"],button:not([type])');
    if (button && !button.dataset.noLoading) {
      button.dataset.original = button.textContent;
      button.textContent = 'Please wait…';
    }
  });
});
