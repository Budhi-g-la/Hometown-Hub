# Internship Portal Submission Checklist

The portal requests five HTTPS links:

1. **GitHub Repository Link** – Create a repository for this project, then upload all files from this folder.
2. **Detailed Project Report Link** – Upload `Detailed_Project_Report.pdf` to the repository or a shareable cloud drive. Copy its HTTPS link.
3. **Project Deployed Link** – Deploy this repository using the included `render.yaml` Blueprint configuration. Copy the generated HTTPS service URL after the deployment succeeds.
4. **Project Explanation Video Link** – Record the project walkthrough using `VIDEO_SCRIPTS.md`, upload it, and copy its shareable HTTPS link.
5. **Internship Experience & Feedback Video Link** – Record your own honest experience/feedback using the second script, upload it, and copy its shareable HTTPS link.

Do not paste example URLs or links to files that are not actually uploaded. Test every link in a private/incognito browser window and confirm the reviewer can open it.
